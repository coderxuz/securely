# Securely

**Securely** is a Python package that helps with authentication and authorization in FastAPI applications.

## Installation

You can install the package via `pip`:

```bash
pip install securely
